PRISON LIFE — CELA / ASSET PACK

WAŻNE:
Nie każ Replitowi samodzielnie projektować ani rozmieszczać celi.
Ta paczka rozdziela:
1. gotowe tło sceny,
2. dokładny layout/pozycje obiektów,
3. późniejsze assety ulepszeń.

NA TEN MOMENT:
cell-background.webp = pełne tło celi.
cell-layout-guide.webp = wizualna mapa miejsc, w których mają znajdować się interaktywne elementy.
cell-layout.json = dokładne pozycje w procentach.

IMPLEMENTACJA:
- cell-background.webp ma być tłem całego kontenera sceny.
- Obiekty mają być pozycjonowane ABSOLUTNIE względem tego samego kontenera.
- Nie używać flexbox/grid do rozmieszczania obiektów sceny.
- Nie zmieniać pozycji po ulepszeniu.
- Ulepszenie = podmiana assetu obiektu w tym samym slocie.
- Klikalny hitbox = dokładnie ten sam prostokąt co slot assetu.
- Cała scena ma skalować się proporcjonalnie.

STRUKTURA DO DOŁOŻENIA:
assets/cell/
  cell-background.webp
  cell-layout-guide.webp
  cell-layout.json
  bed/
    level-01.webp
    level-02.webp
    ...
  locker/
    level-01.webp
    level-02.webp
    ...
  table/
    level-01.webp
    ...
  etc.

Najpierw zaimplementuj scenę na samym backgroundzie + placeholderach slotów.
Dopiero potem podłączaj osobne assety mebli.
