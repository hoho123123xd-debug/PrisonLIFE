# Prison Life — Top HUD

To jest pierwsza wersja wdrożeniowa oparta bezpośrednio na zaakceptowanym masterze HUD-u.

## Najważniejsza decyzja

Nie próbujemy odtwarzać tekstur, łańcuchów, rdzy, śrub i całej kompozycji CSS-em. Master artwork jest renderowany jako jeden obraz, dzięki czemu wygląd pozostaje 1:1 względem zaakceptowanej referencji.

React obsługuje nad nim przezroczyste, prawdziwe przyciski.

## Uruchomienie w Replit

```bash
npm install
npm run dev
```

## Kolejny etap

Gdy przygotujemy wersję tła bez tekstów i wartości, można włączyć prawdziwe dynamiczne warstwy React:
- nick,
- poziom,
- XP,
- gotówkę,
- punkty,
- energię,
- licznik wiadomości.

Na tym etapie nie zmieniaj proporcji ani geometrii HUD-u.
