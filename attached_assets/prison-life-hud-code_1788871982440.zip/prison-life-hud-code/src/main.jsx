import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./hud.css";

/*
  PRISON LIFE — TOP HUD
  ---------------------------------------------------------
  The accepted HUD artwork is intentionally used as a single
  visual skin. This guarantees pixel-stable geometry.
  The interactive hitboxes are HTML buttons positioned over it.
  Replace the skin later with separated assets if desired.
*/

const initialPlayer = {
  nickname: "F1qu",
  gang: "BANG SZCZUR",
  level: 18,
  xp: 2450,
  xpMax: 4200,
  cash: "100 250 $",
  points: "1003",
  energy: 100,
  energyMax: 100,
  block: "BLOK C",
  unread: 3,
};

export default function PrisonHUD({ player = initialPlayer, onAction }) {
  const [messageCount, setMessageCount] = useState(player.unread);

  const xpPercent = useMemo(
    () => Math.max(0, Math.min(100, (player.xp / player.xpMax) * 100)),
    [player.xp, player.xpMax]
  );

  const handle = (name) => {
    if (name === "mail") setMessageCount(0);
    onAction?.(name);
  };

  return (
    <div className="hud-wrap">
      <div className="hud-art" aria-hidden="true" />

      {/* Accessible interactive layer */}
      <div className="hud-hit-layer">
        <button className="hit hit-logo" onClick={() => handle("home")} aria-label="Prison Life — strona główna" />
        <button className="hit hit-player" onClick={() => handle("character")} aria-label="Twoja postać" />
        <button className="hit hit-cash" onClick={() => handle("cash")} aria-label="Gotówka" />
        <button className="hit hit-points" onClick={() => handle("points")} aria-label="Punkty" />
        <button className="hit hit-energy" onClick={() => handle("energy")} aria-label="Energia" />
        <button className="hit hit-mail" onClick={() => handle("mail")} aria-label="Wiadomości">
          {messageCount > 0 && <span className="badge">{messageCount}</span>}
        </button>
        <button className="hit hit-settings" onClick={() => handle("settings")} aria-label="Ustawienia" />
        <button className="hit hit-logout" onClick={() => handle("logout")} aria-label="Wyloguj" />
      </div>

      {/* Optional live-data layer.
          Keep disabled by default because the supplied skin already contains
          the approved typography/content. Turn on `.live-layer` only after
          preparing a clean, text-free HUD background. */}
      <div className="live-layer" aria-hidden="true">
        <span className="live-xp" style={{ "--xp": `${xpPercent}%` }} />
        <span className="live-energy" style={{ "--energy": `${(player.energy / player.energyMax) * 100}%` }} />
      </div>
    </div>
  );
}

function App() {
  return (
    <main className="demo">
      <PrisonHUD onAction={(action) => console.log("HUD action:", action)} />
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);
